package JDBC.JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class jdbcconnectivity {

	public static void main(String[] args) {
		Connection connection = null;

		try {

			String dbUrl = "jdbc:sqlite:C:/Users/musht/Pictures/Screenshots/Shaffna/new database.db";
			connection = DriverManager.getConnection(dbUrl);
			System.out.println("Connection to SQLite has been established.");

			Statement statement = connection.createStatement();

			String dropTableQuery = "DROP TABLE IF EXISTS employee;";
			statement.execute(dropTableQuery);
			System.out.println("Table 'employee' dropped (if it existed).");

			String createTableQuery = "CREATE TABLE IF NOT EXISTS employee (" + "empcode INTEGER PRIMARY KEY, "
					+ "empname TEXT NOT NULL, " + "empage INTEGER NOT NULL, " + "esalary INTEGER NOT NULL);";
			statement.execute(createTableQuery);
			System.out.println("Table 'employee' created successfully (if not already exists).");

			String insertQuery = "INSERT OR IGNORE INTO employee (empcode, empname, empage, esalary) VALUES "
					+ "(101, 'Jenny', 25, 10000), " + "(102, 'Jacky', 30, 20000), " + "(103, 'Joe', 20, 40000), "
					+ "(104, 'John', 40, 80000), " + "(105, 'Shameer', 25, 90000);";
			statement.executeUpdate(insertQuery);
			System.out.println("All rows inserted successfully (duplicates ignored).");

			waitForFixTime(5000);
			System.out.println("5-second delay over.");

			String selectQuery = "SELECT * FROM employee;";
			ResultSet resultSet = statement.executeQuery(selectQuery);

			System.out.println("Employee Table Data:");
			while (resultSet.next()) {
				int empcode = resultSet.getInt("empcode");
				String empname = resultSet.getString("empname");
				int empage = resultSet.getInt("empage");
				int esalary = resultSet.getInt("esalary");
				System.out.println(empcode + " | " + empname + " | " + empage + " | " + esalary);
			}

			resultSet.close();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (connection != null) {
					connection.close();
					System.out.println("Database connection closed.");
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}

	public static void waitForFixTime(int time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
